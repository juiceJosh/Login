import React, { Component } from 'react';
import {Alert} from 'react-native';
import { Button, Card, CardSection, Input } from './common';

class LoginForm extends Component { 

 state =  { email: '', password: '' };

 onButtonPress(){
    if(this.state.email === "user123@gmail.com" && this.state.password ==="qwertyuiop123"){
        Alert.alert("Success","Welcome to Daloy", [
            { text: "Later", onPress: () => console.log("later pressed") },
            {
              text: "Cancel",
              onPress: () => console.log("Cancel Pressed"),
              style: "cancel"
            },
            { text: "OK", onPress: () => console.log("OK Pressed") }
          ],
          { cancelable: false }
        );
    }
    else{
        Alert.alert("Incorrect Credentials");
    }
 }

 render(){
  return (
    <Card>
       <CardSection>
           <Input
            keyboardType='email-address'
            label="Email"
            placeholder="user@gmail.com"
            value = {this.state.email}
            onChangeText={email => this.setState({ email })}
           />   
       </CardSection>
       <CardSection>
           <Input 
            label="Password"
            placeholder="*******"
            secureTextEntry={true}
            value = {this.state.password}
            onChangeText={password => this.setState({ password })}
           />
       </CardSection>
       <CardSection>
            <Button onPress ={this.onButtonPress.bind(this)}>
               Log In
            </Button> 
       </CardSection>
    </Card>
   );
 }
}

export default LoginForm;
