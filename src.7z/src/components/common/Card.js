import React from 'react'; 
import { View } from 'react-native';

//this component is just for styling that looks like a card

const Card = (props) => {
    return (
        <View style={styles.cardStyle}>
            {props.children} 
        </View>
    ); //props.children will reference the children
};

const styles = {

    cardStyle: {
        borderWidth: 1,
        borderRadius: 2, //fillet the corners
        borderColor: '#ddd',
        borderBottomwidth: 0, //just hide the border entirely
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.2,
        shadowRadius: 2,
        elevation: 1,
        marginLeft: 5,
        marginRight: 5,
        marginTop: 10,
        position: 'relative' 
    }
};
export { Card };