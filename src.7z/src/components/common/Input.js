import React from 'react';
import { View, TextInput , Text } from 'react-native';

const Input = ({label, value, onChangeText, placeholder, secureTextEntry, keyboardType}) => {
 const {inputStyle, labelStyle, containerStyle } = styles;
   
 return(
     <View style={containerStyle}>
         <Text style={labelStyle}>{label}</Text>
         <TextInput 
           keyboardType = {keyboardType}
           secureTextEntry={secureTextEntry}
           autoCorrect={false}
           placeholder={placeholder}
           style={inputStyle}
           value = {value}
           onChangeText={onChangeText}
           />
     </View>
 );
};

const styles = {
    containerStyle: { 
      height: 40,
      flex: 1,
      flexDirection: 'row',
      alignItems: 'center',
    },

    labelStyle: {
        fontSize: 14,
        paddingLeft: 20,
        flex: 1
    },

    inputStyle: {
        color: 'black',
        paddingLeft: 5,
        paddingRight: 5,
        flex:2,
        fontSize: 14,
        lineHeight: 19,
    }
  };

export { Input };  