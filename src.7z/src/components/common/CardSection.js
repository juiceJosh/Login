import React from 'react'; 
import { View } from 'react-native';

const CardSection = (props) => {
    return (
        <View style={styles.cardStyle}>
            {props.children}
        </View>
    ); //props.children will reference the children
};

const styles = {

    cardStyle: {
        borderBottomwidth: 1, 
        padding: 5,
        backgroundColor: '#fff',
        justifyCOntent: 'flex-start',
        flexDirection: 'row',
        borderColor: '#ddd',
        postion: 'relative' 
    }
};

export {CardSection};
